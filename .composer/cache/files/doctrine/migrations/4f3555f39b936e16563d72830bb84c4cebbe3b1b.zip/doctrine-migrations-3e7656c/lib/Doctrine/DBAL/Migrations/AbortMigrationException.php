<?php

namespace Doctrine\DBAL\Migrations;

class AbortMigrationException extends MigrationException
{
}
