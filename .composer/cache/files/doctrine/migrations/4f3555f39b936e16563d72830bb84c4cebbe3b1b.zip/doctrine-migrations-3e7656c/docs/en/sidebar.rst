.. toctree::
   :depth: 3

   reference/introduction
   reference/installation
   reference/integration
   reference/building_framework_specific_integration
   reference/migration_classes
   reference/managing_migrations
   reference/generating_migrations
   reference/custom_configuration
   reference/input_output_customization
   reference/events
   reference/version_numbers
